KAX R2.2.2
0.24 HOTFIX

Note: This is a 0.24 compatibility hotfix, some features may be missing or buggy.

Extract included folders into your Gamedata folder.  If you already have an existing plugin that KAX requires, use the lastest version.

See the official thread for details: http://forum.kerbalspaceprogram.com/threads/76668

===========================CREDITS===========================


KAX wouldn't be possible without Firespitter!
Big thanks to Snjo and the Firespitter mod & plugin: http://forum.kerbalspaceprogram.com/threads/24551




