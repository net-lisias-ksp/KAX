# TweakScale support

These patches were internalized to KAX following Issue TweakScale#69 guidelines
    * https://github.com/net-lisias-ksp/TweakScale/issues/69

 This patch is under KAX's copyright from now on.
