# KAX /L :: Known Issues

* The C2B Horizon Cockpit has issues on the hatch
	+ Kerbals are spilled out, and there's no way to get back inside
* The Space used is far from adequate for the cockpit! :)
* The JumpJet isn't working as expected!


 
